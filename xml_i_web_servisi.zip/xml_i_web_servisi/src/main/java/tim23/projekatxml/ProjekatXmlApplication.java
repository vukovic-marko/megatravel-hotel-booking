package tim23.projekatxml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjekatXmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjekatXmlApplication.class, args);
	}

}
